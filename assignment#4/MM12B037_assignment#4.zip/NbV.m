function [outputs] = NbV(xNb, xV)
	% element wise multiplication
	outputs = xNb.*xV*-1875;
end