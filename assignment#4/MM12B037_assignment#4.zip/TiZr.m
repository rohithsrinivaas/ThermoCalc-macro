function [outputs] = TiZr(xTi, xZr)
	% element wise multiplication
	outputs = xTi.*xZr.*-968;
end