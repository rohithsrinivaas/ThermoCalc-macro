function [outputs] = NbTi(xNb, xTi)
	% element wise multiplication
	outputs = xNb*xTi*3000;
end